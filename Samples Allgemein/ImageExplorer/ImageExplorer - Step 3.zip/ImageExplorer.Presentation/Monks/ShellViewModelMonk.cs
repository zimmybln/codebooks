﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ImageExplorer.Presentation.Monks
{
    class ShellViewModelMonk : ImageExplorer.Base.IShellViewModel
    {
        public object ContentView
        {
            get { return null; }
            set { }
        }

        public void Show()
        {
            
        }

        public void Close()
        {
            
        }
    }
}
