﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Input;

namespace ImageExplorer.Presentation.Monks
{
    public class MainViewModelMonk : ImageExplorer.Base.IMainViewModel
    {
        public ICommand SayHelloCommand
        {
            get { return null; }
        }
    }
}
