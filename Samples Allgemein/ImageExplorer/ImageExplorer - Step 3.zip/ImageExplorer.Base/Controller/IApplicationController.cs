namespace ImageExplorer.Base
{
    public interface IApplicationController
    {
        void Initialize();
        void Run();
        void Close();
        void Shutdown();
    }
}