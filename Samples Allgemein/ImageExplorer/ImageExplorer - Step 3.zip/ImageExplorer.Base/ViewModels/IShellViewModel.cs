namespace ImageExplorer.Base
{
    public interface IShellViewModel
    {
        object ContentView { get; set; }
        void Show();
        void Close();
    }
}