﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Waf.Applications;
using System.Windows;
using ImageExplorer.Base;

namespace ImageExplorer.App
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private CompositionContainer mv_objCompositionContainer;
        private IApplicationController mv_objApplicationController;


        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Erstellung der Kataloge
            var catalog = new AggregateCatalog();
            
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Controller).Assembly));
            
            catalog.Catalogs.Add(new AssemblyCatalog(Assembly.LoadFrom("ImageExplorer.Applications.dll")));
            catalog.Catalogs.Add(new AssemblyCatalog(Assembly.LoadFrom("ImageExplorer.Presentation.dll")));

            // Erstellung des Containers für die Zusammenstellung
            mv_objCompositionContainer = new CompositionContainer(catalog);

            // Abarbeitung der Zusammenstellung
            CompositionBatch batch = new CompositionBatch();
            batch.AddExportedValue(mv_objCompositionContainer);
            mv_objCompositionContainer.Compose(batch);

            // Anwendungscontroller ermitteln und ausführen
            mv_objApplicationController = mv_objCompositionContainer.GetExportedValue<IApplicationController>();
            mv_objApplicationController.Initialize();
            mv_objApplicationController.Run();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            // Aufräumarbeiten
            mv_objApplicationController.Shutdown();
            mv_objCompositionContainer.Dispose();

            base.OnExit(e);
        }

    }
}
