﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Waf.Applications;
using System.Windows;
using System.Windows.Input;

namespace ImageExplorer.Applications
{
    [Export]
    public class MainViewModel : ViewModel<IMainView>
    {
        private readonly ICommand mv_cmdSayHelloCommand;

        [ImportingConstructor]
        public MainViewModel(IMainView view)
            : base(view)
        {

            mv_cmdSayHelloCommand = new DelegateCommand(SayHello);
        }

        public ICommand SayHelloCommand { get { return mv_cmdSayHelloCommand; } }

        private void SayHello()
        {
            MessageBox.Show("Hallo, ich komme aus einem Modell");
        }
    }
}
