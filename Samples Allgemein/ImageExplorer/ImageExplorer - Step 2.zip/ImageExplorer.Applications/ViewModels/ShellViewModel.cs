﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Waf.Applications;

namespace ImageExplorer.Applications
{
    [Export]
    public class ShellViewModel : ViewModel<IShellView>
    {
        private object contentView;

        [ImportingConstructor]
        public ShellViewModel(IShellView view)
            : base(view)
        {

        }

        public object ContentView
        {
            get { return contentView; }
            set
            {
                if (contentView != value)
                {
                    contentView = value;
                    RaisePropertyChanged("ContentView");
                }
            }
        }

        public static string Title { get { return ApplicationInfo.ProductName; } }

        public void Show()
        {
            ViewCore.Show();
        }

        public void Close()
        {
            ViewCore.Close();
        }
    }
}
