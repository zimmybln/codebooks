﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Waf.Applications;

namespace ImageExplorer.Applications
{
    public interface IShellView : IView
    {
        void Show();

        void Close();
    }
}
