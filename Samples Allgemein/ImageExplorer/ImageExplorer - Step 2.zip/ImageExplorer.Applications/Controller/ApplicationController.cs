﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.Linq;
using System.Text;

using System.ComponentModel.Composition;
using System.Waf;
using System.Waf.Applications;


namespace ImageExplorer.Applications
{
    [Export()]
    public class ApplicationController : Controller
    {
        private readonly CompositionContainer mv_implCompositionContainer;
        private readonly ShellViewModel mv_implShellViewModel;
        private readonly MainViewModel mv_implMainViewModel;
        
        [ImportingConstructor]
        public ApplicationController(CompositionContainer container)
        {
            mv_implCompositionContainer = container;

            mv_implShellViewModel = mv_implCompositionContainer.GetExportedValue<ShellViewModel>();
            mv_implMainViewModel = mv_implCompositionContainer.GetExportedValue<MainViewModel>();
        }

        public void Initialize()
        {
            // Momentan gibt es hier nichts zu tun
        }


        public void Run()
        {
            // 
            mv_implShellViewModel.ContentView = mv_implMainViewModel.View;
            mv_implShellViewModel.Show();
        }

        public void Close()
        {
            mv_implShellViewModel.Close();
        }

        public void Shutdown()
        {
            // Momentan gibt es hier nichts zu tun
        }


    }
}
