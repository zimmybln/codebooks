﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ImageExplorer.Applications;

namespace ImageExplorer.Presentation.Views
{
    /// <summary>
    /// Interaction logic for MainWindows.xaml
    /// </summary>
    [Export(typeof(IMainView))]
    public partial class MainWindow : UserControl, IMainView
    {

        public MainWindow()
        {
            InitializeComponent();
            this.DataContextChanged += OnDataContextChanged;
        }

        private MainViewModel ViewModel { get { return DataContext as MainViewModel; } }

        private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
           kbExitCommand.Command = ViewModel.SayHelloCommand;
        }


    }
}
