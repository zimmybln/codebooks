﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Waf.Applications;
using System.Windows;
using ImageExplorer.Applications;

namespace ImageExplorer.Presentation
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private CompositionContainer mv_objCompositionContainer;
        private ApplicationController mv_objApplicationController;


        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);


            AggregateCatalog catalog = new AggregateCatalog();
            
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(Controller).Assembly));
            
            catalog.Catalogs.Add(new AssemblyCatalog(Assembly.GetExecutingAssembly()));
            
            catalog.Catalogs.Add(new AssemblyCatalog(typeof(ApplicationController).Assembly));

            mv_objCompositionContainer = new CompositionContainer(catalog);
            CompositionBatch batch = new CompositionBatch();
            batch.AddExportedValue(mv_objCompositionContainer);
            mv_objCompositionContainer.Compose(batch);

            mv_objApplicationController = mv_objCompositionContainer.GetExportedValue<ApplicationController>();
            mv_objApplicationController.Initialize();
            mv_objApplicationController.Run();
        }

        protected override void OnExit(ExitEventArgs e)
        {
            mv_objApplicationController.Shutdown();
            mv_objCompositionContainer.Dispose();

            base.OnExit(e);
        }

    }
}
