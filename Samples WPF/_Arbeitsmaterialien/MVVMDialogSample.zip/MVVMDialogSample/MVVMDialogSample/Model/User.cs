﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Diagnostics;

namespace MVVMDialog.Model
{
    /// <summary>
    /// Sample model.
    /// </summary>
    public class User
    {   
        public string Name { get; set; }
    }
}
