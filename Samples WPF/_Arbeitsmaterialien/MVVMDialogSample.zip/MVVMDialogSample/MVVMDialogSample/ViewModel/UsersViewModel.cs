﻿using System.Collections.ObjectModel;
using MVVMDialog.Model;
using System.Windows.Input;
using System;
using System.Windows;

namespace MVVMDialog.ViewModel
{
    /// <summary>
    /// The ViewModel representing the Users model.
    /// </summary>
    public class UsersViewModel : DependencyObject
    {
        #region Dependency Properties
        public static readonly DependencyProperty DialogViewModelPropertyProperty = DependencyProperty.Register("DialogViewModel", typeof(object), typeof(UsersViewModel), new UIPropertyMetadata(null));

        /// <summary>
        /// Set this to a ViewModel to display the dialog.
        /// </summary>
        public object DialogViewModel
        {
            get { return (object)GetValue(DialogViewModelPropertyProperty); }
            set { SetValue(DialogViewModelPropertyProperty, value); }
        }
        #endregion

        #region Commands
        /// <summary>
        /// Call this command to start adding a user.
        /// </summary>
        public ICommand AddUserCommand { get; set; }
        /// <summary>
        /// Call this command to accept the new user.
        /// </summary>
        public ICommand AddUserAcceptCommand { get; set; }
        /// <summary>
        /// Call this command to cancel adding a new user.
        /// </summary>
        public ICommand CancelAddUserCommand { get; set; }
        #endregion

        ObservableCollection<UserViewModel> _userViewModels;
        Users _users;

        public UsersViewModel(Users users)
        {
            AddUserCommand = new AddUserInternalCommand(this);
            AddUserAcceptCommand = new AddUserAcceptInternalCommand(this);
            CancelAddUserCommand = new CancelAddUserInternalCommand(this);
            
            this._users = users;
            this._userViewModels = new ObservableCollection<UserViewModel>();
            foreach (User user in this._users)
            {
                this._userViewModels.Add(new UserViewModel(user));
            }
        }

        /// <summary>
        /// Expose all the UserViewModels for display in the ListBox.
        /// </summary>
        public ObservableCollection<UserViewModel> Users 
        {
            get
            {
                return _userViewModels;
            }
        }

        /// <summary>
        /// Used by the AddUserCommand.
        /// </summary>
        /// <returns>True if the AddUserCommand can be called.</returns>
        public bool CanAddUser()
        {
            return true;
        }

        public void AddUser()
        {
            //Set the Dialog property to be the new UserViewModel
            User user = new User();
            user.Name = "Unnamed";
            UserViewModel userViewModel = new UserViewModel(user);
            userViewModel.AddUserAccepted += delegate
            {
                AcceptAddUser();
            };
            /*userViewModel.AddUserCanceled += delegate
            {
                CancelAddUser();
            };*/

            DialogViewModel = userViewModel;
        }

        /// <summary>
        /// Used by AccepAddUserCommand.
        /// </summary>
        /// <returns>True if AcceptAddUserCommand can be called.</returns>
        public bool CanAddUserAccept()
        {
            return DialogViewModel != null;
        }

        public void AcceptAddUser()
        {
            UserViewModel userViewModel = DialogViewModel as UserViewModel;
            this._userViewModels.Add(userViewModel);
            this._users.Add(userViewModel.Model);
            DialogViewModel = null;
        }

        public void CancelAddUser()
        {
            DialogViewModel = null;
        }

        #region Commands
        class AddUserInternalCommand : ICommand
        {
            UsersViewModel _viewModel;

            public AddUserInternalCommand(UsersViewModel viewModel)
            {
                this._viewModel = viewModel;
            }

            #region ICommand Members

            public bool CanExecute(object parameter)
            {
                return this._viewModel.CanAddUser();
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                this._viewModel.AddUser();
            }

            #endregion
        }

        class AddUserAcceptInternalCommand : ICommand
        {
            UsersViewModel _viewModel;

            public AddUserAcceptInternalCommand(UsersViewModel viewModel)
            {
                this._viewModel = viewModel;
            }

            #region ICommand Members

            public bool CanExecute(object parameter)
            {
                return this._viewModel.CanAddUserAccept();
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                this._viewModel.AcceptAddUser();
            }

            #endregion
        }

        class CancelAddUserInternalCommand : ICommand
        {
            UsersViewModel _viewModel;

            public CancelAddUserInternalCommand(UsersViewModel viewModel)
            {
                this._viewModel = viewModel;
            }

            #region ICommand Members

            public bool CanExecute(object parameter)
            {
                return this._viewModel.DialogViewModel != null;
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                this._viewModel.DialogViewModel = null;
            }

            #endregion
        }
        #endregion Commands
    }
}
