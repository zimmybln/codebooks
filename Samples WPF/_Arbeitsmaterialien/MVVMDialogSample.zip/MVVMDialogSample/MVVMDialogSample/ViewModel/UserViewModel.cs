﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MVVMDialog.Model;
using System.Windows;
using System.Windows.Input;

namespace MVVMDialog.ViewModel
{
    public class UserViewModel : DependencyObject
    {
        public ICommand AcceptAddUserCommand { get; set; }
        public event EventHandler AddUserAccepted;
        public ICommand CancelAddUserCommand { get; set; }
        //public event EventHandler AddUserCanceled;

        private User _user;

        public User Model
        {
            get
            {
                return this._user;
            }
        }

        public string Name
        {
            get { return (string)GetValue(NamePropertyProperty); }
            set { SetValue(NamePropertyProperty, value); }
        }

        private bool CanAcceptAddUser()
        {   
            return true;
        }

        private void AcceptAddUser()
        {
            //Raise an event to tell UsersViewModel.
            AddUserAccepted(this, EventArgs.Empty);
        }

        /*private bool CanCancelAddUser()
        {
            return true;
        }

        private void CancelAddUser()
        {
            AddUserCanceled(this, EventArgs.Empty);
        }*/
        
        public static readonly DependencyProperty NamePropertyProperty =
            DependencyProperty.Register("Name", typeof(string), typeof(UserViewModel));

        public UserViewModel() : this(new User())
        {   
        }

        public UserViewModel(User user)
        {
            AcceptAddUserCommand = new AcceptAddUserInternalCommand(this);
            //CancelAddUserCommand = new CancelAddUserInternalCommand(this);
            this._user = user;
            this.Name = this._user.Name;
        }

        #region Commands
        class AcceptAddUserInternalCommand : ICommand
        {
            UserViewModel _viewModel;

            public AcceptAddUserInternalCommand(UserViewModel viewModel)
            {
                this._viewModel = viewModel;
            }

            #region ICommand Members

            public bool CanExecute(object parameter)
            {
                return this._viewModel.CanAcceptAddUser();
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                this._viewModel.AcceptAddUser();
            }

            #endregion
        }

        /*class CancelAddUserInternalCommand : ICommand
        {
            UserViewModel _viewModel;

            public CancelAddUserInternalCommand(UserViewModel viewModel)
            {
                this._viewModel = viewModel;
            }

            #region ICommand Members

            public bool CanExecute(object parameter)
            {
                return this._viewModel.CanCancelAddUser();
            }

            public event EventHandler CanExecuteChanged
            {
                add { CommandManager.RequerySuggested += value; }
                remove { CommandManager.RequerySuggested -= value; }
            }

            public void Execute(object parameter)
            {
                this._viewModel.CancelAddUser();
            }

            #endregion
        }*/
        #endregion
    }
}
