﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Apex.Controls
{
  /// <summary>
  /// The Cross Button is a very simple version of the button that displays as a discrete cross,
  /// similar to the buttons at the top of Google Chrome's tabs.
  /// </summary>
    public class CrossButton : Button
    {
#if !SILVERLIGHT
        /// <summary>
        /// Initializes the <see cref="CrossButton"/> class.
        /// </summary>
        static CrossButton()
        {
          //  Set the style key, so that our control template is used.
            DefaultStyleKeyProperty.OverrideMetadata(typeof(CrossButton), new FrameworkPropertyMetadata(typeof(CrossButton)));
        }
#else        
        /// <summary>
        /// Initializes a new instance of the <see cref="CrossButton"/> class.
        /// </summary>
        public CrossButton()
        {
            this.DefaultStyleKey = typeof(CrossButton);
        }
#endif
    }
}
