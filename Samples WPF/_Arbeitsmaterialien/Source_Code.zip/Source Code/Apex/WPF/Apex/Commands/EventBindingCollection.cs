﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Windows.Markup;
using System.Windows;
using System.Windows.Controls;
using Apex.Consistency;

namespace Apex.Commands
{
    public class EventBindingCollection : FreezableCollection<EventBinding>
    {
    }
}
