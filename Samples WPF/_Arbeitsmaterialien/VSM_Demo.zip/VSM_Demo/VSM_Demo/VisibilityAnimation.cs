﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Media.Animation;
using System.Windows;

namespace VSM_Demo
{
    class VisibilityAnimation : ObjectAnimationUsingKeyFrames
    {
        public Visibility VisbilityState { get; set; }

        public VisibilityAnimation()
        {
            Storyboard.SetTargetProperty(this, new PropertyPath(UIElement.VisibilityProperty));

            DiscreteObjectKeyFrame frame = new DiscreteObjectKeyFrame(VisbilityState, KeyTime.FromTimeSpan(new TimeSpan(0)));

            this.AddChild(frame);
        }
    }
}
