﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows;

namespace VSM_Demo.ViewModels
{
    public class ViewModelBase : INotifyPropertyChanged
    {
        #region ctors

        public ViewModelBase(UserControl view)
        {
            View = view;
            View.DataContext = this;
        }

        #endregion

        #region properties

        public UserControl View { get; set; }

        #endregion

        #region methods

        public bool GoToState(string stateName, bool useTransitions)
        {
            return VisualStateManager.GoToState(View, stateName, useTransitions);
        }

        #endregion

        #region property changed

        public void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion
    }
}
