﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using VSM_Demo.Views;
using Microsoft.Practices.Composite.Presentation.Commands;
using System.ComponentModel;
using System.Threading;
using System.Windows;

namespace VSM_Demo.ViewModels
{
    public class SearchViewModel : ViewModelBase
    {
        #region ctors

        public SearchViewModel(SearchView view) : base(view)
        {
            SearchCommand = new DelegateCommand<object>(OnSearch);
            ResetCommand = new DelegateCommand<object>(OnReset);

            GoToState("SearchInitialized", false);
        }

        #endregion

        #region properties

        public DelegateCommand<object> SearchCommand { get; set; }
        public DelegateCommand<object> ResetCommand { get; set; }

        private int _percentSearchCompleted;
        public int PercentSearchCompleted 
        {
            get
            {
                return _percentSearchCompleted;
            }
            set
            {
                _percentSearchCompleted = value;
                OnPropertyChanged("PercentSearchCompleted");
            }
        }

        #endregion

        #region methods

        public void OnSearch(object parameter)
        {
            BackgroundWorker worker = new BackgroundWorker();
            worker.WorkerReportsProgress = true;
            worker.DoWork += new DoWorkEventHandler(worker_DoWork);
            worker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(worker_RunWorkerCompleted);
            worker.ProgressChanged += new ProgressChangedEventHandler(worker_ProgressChanged);

            VisualStateManager.GoToState(View, "SearchStarted", false);

            worker.RunWorkerAsync();
        }

        public void OnReset(object parameter)
        {
            GoToState("SearchInitialized", false);
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = (BackgroundWorker)sender;

            int percentCompleted = 0;

            worker.ReportProgress(percentCompleted);

            for (int i = 0; i < 4; i++)
            {
                Thread.Sleep(1000);
                percentCompleted += 25;
                worker.ReportProgress(percentCompleted);
            }
        }

        void worker_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            PercentSearchCompleted = e.ProgressPercentage;
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            GoToState("SearchCompleted", false);

            ((BackgroundWorker)sender).Dispose();
        }

        

        #endregion
    }
}
