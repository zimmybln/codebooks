using System.Reflection;
using System.Resources;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows;

// Allgemeine Informationen �ber eine Assembly werden �ber die folgenden 
// Attribute gesteuert. �ndern Sie diese Attributwerte, um die Informationen zu �ndern,
// die mit einer Assembly verkn�pft sind.
[assembly: AssemblyTitle("Splash-Fenster")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Splash-Fenster")]
[assembly: AssemblyCopyright("Copyright � 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Durch Festlegen von ComVisible auf "false" werden die Typen in dieser Assembly unsichtbar 
// f�r COM-Komponenten. Wenn Sie auf einen Typ in dieser Assembly von 
// COM zugreifen m�ssen, legen Sie das ComVisible-Attribut f�r diesen Typ auf "true" fest.
[assembly: ComVisible(false)]

// Angabe des themen-spezifischen Ressourcen-Verzeichnis und des Verzeichnisses f�r allgemeine Ressourcen
[assembly: ThemeInfo(
   // Gibt an, ob und in welcher Assembly die themen-spezifischen Ressourcen verwaltet werden.
   // Wenn Sie innerhalb der Assembly themen-spezifische Ressourcen verwalten wollen, geben Sie statt
   // ResourceDictionaryLocation.None den Wert ResourceDictionaryLocation.SourceAssembly an.
   // ResourceDictionaryLocation.ExternalAssembly steht daf�r, dass die Ressourcen 
   // in einer anderen Assembly verwaltet werden.
   // Die Ressourcen f�r die einzelnen Themen m�ssen dann in folgenden Dateien gespeichert werden:
   //     Themes\Aero.NormalColor.xaml
   //     Themes\Classic.xaml
   //     Themes\Luna.Homestead.xaml
   //     Themes\Luna.Metallic.xaml
   //     Themes\Luna.NormalColor.xaml
   //     Themes\Royale.NormalColor.xaml
   ResourceDictionaryLocation.None,

   // Gibt an, ob und in welcher Assembly die nicht themen-spezifischen 
   // Ressourcen verwaltet werden.
   ResourceDictionaryLocation.SourceAssembly)]

// Versionsinformationen f�r eine Assembly bestehen aus den folgenden vier Werten:
//
//      Hauptversion
//      Nebenversion 
//      Buildnummer
//      Revision

// Sie k�nnen alle Werte angeben, oder Sie k�nnen Standard-Build und Revision-Werte verwenden,
// indem Sie '*' verwenden:
// [assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
