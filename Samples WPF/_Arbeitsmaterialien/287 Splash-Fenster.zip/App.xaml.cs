using System;
using System.Windows;
using System.Windows.Threading;

namespace Splash_Fenster
{
   /// <summary>
   /// Interaktions-Logik f�r App.xaml
   /// </summary>
   public partial class App : Application
   {
      protected override void OnStartup(StartupEventArgs e)
      {
         base.OnStartup(e);

         #region Version ohne Aktualisierung

         //// Splash-Fenster �ffnen
         //SplashWindow splashWindow = new SplashWindow();
         //splashWindow.Show();

         //// Die Initialisierung ausf�hren
         //for (int i = 0; i < 100; i++)
         //{
         //   // Die Initialisierung wird hier nur simuliert 
         //   System.Threading.Thread.Sleep(30);
         //}

         //// Das Hauptfenster erzeugen, der Anwendung zuweisen
         //// und �ffnen
         //MainWindow mainWindow = new MainWindow();
         //this.MainWindow = mainWindow;
         //mainWindow.Show();

         //// Schlie�en des Splash-Fensters
         //splashWindow.Close();

         #endregion

         // Splash-Fenster �ffnen
         SplashWindow splashWindow = new SplashWindow();
         splashWindow.Show();

         // Delegat f�r die asynchrone Ausf�hrung
         // der Initialisierung
         Action initializer = new Action(() =>
         {
            // Simulation einer Initialisierung
            try
            {
               /* ******* Initialisierung ******** */
               for (int i = 0; i < 100; i++)
               {
                  // Das Splash-Fenster aktualisieren
                  splashWindow.Dispatcher.Invoke(DispatcherPriority.Normal,
                      new Action(() =>
                      {
                         splashWindow.SetInfo("Lese Datensatz " + i + " ...", i);
                      }));

                  // Die eigentliche Initialisierung wird hier nur simuliert
                  System.Threading.Thread.Sleep(30);
               }
               /* *** Ende der Initialisierung *** */
            }
            catch (Exception ex)
            {
               MessageBox.Show("Fehler beim Initialisieren: " + ex.Message,
                  "Splash-Fenster", MessageBoxButton.OK, MessageBoxImage.Error);
               this.Shutdown();
            }
         });

         // Delegat f�r den Callback der asynchronen Ausf�hrung
         AsyncCallback splashCloser = new AsyncCallback((result) =>
         {
            // Das Hauptfenster erzeugen, der Anwendung zuweisen
            // und �ffnen
            this.Dispatcher.Invoke(DispatcherPriority.Normal,
               new Action(() =>
               {
                  MainWindow mainWindow = new MainWindow();
                  this.MainWindow = mainWindow;
                  mainWindow.Show();
               }));

            // Schlie�en des Splash-Fensters
            splashWindow.Dispatcher.Invoke(DispatcherPriority.Normal,
               new Action(() =>
               {
                  splashWindow.Close();
               }));
         });

         // Asynchrones Starten der Initialisierung
         initializer.BeginInvoke(splashCloser, null);
      }
   }
}
