﻿using System.Windows;

namespace Splash_Fenster
{
   /// <summary>
   /// Interaktionslogik für SplashWindow.xaml
   /// </summary>
   public partial class SplashWindow : Window
   {
      public SplashWindow()
      {
         InitializeComponent();
      }

      /// <summary>
      /// Schreibt eine Information in das Fenster
      /// </summary>
      /// <param name="info">Die Info</param>
      /// <param name="progress">Ein Fortschrittswert</param>
      public void SetInfo(string info, int progress)
      {
         this.txtInfo.Text = info;
         this.pbr.Value = progress;
      }
   }
}
