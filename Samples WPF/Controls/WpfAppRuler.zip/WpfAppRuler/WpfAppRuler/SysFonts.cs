using System;
using System.Windows;
using System.Collections.ObjectModel;
using System.Windows.Media;
using System.Configuration;
using System.Collections.Generic;
using System.Windows.Shapes;
using System.Text.RegularExpressions;

namespace WpfAppRuler
{
    /// <summary>
    /// There are two SysFont ObservableCollection build methods.
    /// One build a SysFont collection using the System Fonts: CreateFonts()
    /// The other build a SysFont collection using the fonts found in the AppSettings: CreateSlctFonts().
    /// </summary>
	class SysFonts
	{   
        /// <summary>
        /// Build a SysFont collection using system fonts.  Don't allow a FontFamily value into the 
        ///   collection if it is already in the AppSettings list.
        /// </summary>
        /// <returns></returns>
		public static ObservableCollection<SysFonts> CreateFonts()
		{
			ObservableCollection<SysFonts> list = new ObservableCollection<SysFonts>();
            List<string> FontList = new List<string>();

            // This Regular Expresion will extract the Known Color and FontFamily from the AppSettings value.
            Regex exprFonts = new Regex(@"^Color[\=]{1}(?<xColor>[\s\w]{3,24}),FontFamily[\=]{1}(?<xFont>[\s\w]{3,26})", RegexOptions.IgnoreCase);
            MatchCollection xmlElements;
            string strFontFamily ="";
            
            // Get the configuration file and build a FontList that contains Selected Fonts from AppSettings.
            System.Configuration.Configuration configuration =
              ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            string path = configuration.FilePath;

            // Create a list of fonts from the AppSettings in App.Config
            foreach (string key in ConfigurationManager.AppSettings.AllKeys)
            {
                // Font keys are 'Font1 ... Font#'
                if (key.StartsWith("Font", StringComparison.CurrentCultureIgnoreCase))
                {
                    strFontFamily = "";
                    string strAppSetting = ConfigurationManager.AppSettings[key];

                    // Have Regex match and extract the FontFamily.
                    xmlElements = exprFonts.Matches(strAppSetting);

                    foreach (Match tempVar_xmlElem in xmlElements)
                    {
                        strFontFamily = tempVar_xmlElem.Groups[2].Value;
                    }

                    //  Stow the selected font family in an array of string.
                    FontList.Add(strFontFamily);
                }
            }

            //  Create a known color swatch.
            Rectangle xcolorSwatch = new Rectangle();
            xcolorSwatch.Height = double.NaN; // _height;
            xcolorSwatch.Width = 25;
            xcolorSwatch.Fill = System.Windows.Media.Brushes.Black;
            xcolorSwatch.StrokeThickness = 1;
            xcolorSwatch.Stroke = Brushes.DarkGray;
            xcolorSwatch.Margin = new Thickness(1, 1, 1, 1);

            //  Iterate through the available system fonts and add those not already selected 
            //    to the SysFonts collection.
            foreach ( FontFamily fontFamily in Fonts.SystemFontFamilies )
			{
                if (FontList.Contains(fontFamily.Source)) { }
                //  This font family has already been selected 
                else
                {
                    list.Add(new SysFonts("Gray", fontFamily.Source, false));
                }
			}

			return list;
		}

        /// <summary>
        /// Build a SysFont collection from Apps.Config.
        /// </summary>
        /// <returns></returns>
        public static ObservableCollection<SysFonts> CreateSlctFonts()
        {
            ObservableCollection<SysFonts> list = new ObservableCollection<SysFonts>();
            Regex exprFonts = new Regex(@"^Color[\=]{1}(?<xColor>[\s\w]{3,24}),FontFamily[\=]{1}(?<xFont>[\s\w]{3,26})", RegexOptions.IgnoreCase);

            MatchCollection xmlElements;

            foreach (string key in ConfigurationManager.AppSettings.AllKeys)
            {
                if (key.StartsWith("Font", StringComparison.CurrentCultureIgnoreCase))
                {
                    string strFontFamily = "";
                    string strColor = "";

                    String strAppSetting = ConfigurationManager.AppSettings[key];

                    // Have Regex match and extract the FontFamily and the Font Color.
                    xmlElements = exprFonts.Matches(strAppSetting);
                    
                    foreach (Match tempVar_xmlElem in xmlElements)
                    {
                        strColor = tempVar_xmlElem.Groups[1].Value;
                        strFontFamily = tempVar_xmlElem.Groups[2].Value;
                    }

                    //  This logic needs a sanity check to make sure the Regex actually found a font and color.
                    list.Add(new SysFonts(strColor, strFontFamily, false));
                }
            }

            return list;
        }

        Rectangle myColorSwatch = new Rectangle();
        string myColor;
		string name;
		bool updtFnt;

        public SysFonts(string color, string name, bool updtFnt)
		{
			this.name = name;
            this.myColor = color;
			this.updtFnt = updtFnt;
		}

		public bool UpdtOnly
		{
			get { return this.updtFnt; }
			set { this.updtFnt = value; }
		}

		public Rectangle colorSwatch
		{
			get { return this.myColorSwatch; }
		}

		public string Name
		{
			get { return this.name; }
		}

        public string fontColor
        {
            get { return this.myColor; }
            set { this.myColor = value; }
        }
	}
}
