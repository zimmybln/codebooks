﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows;

namespace WpfAppRuler
{
    public class IndentCommandSlider : Slider, ICommandSource
    {
        public IndentCommandSlider()
            : base()
        {
        }

        #region Dependency Properties  //  WPF uses dependency properties to support change notification and dynamic value resolution.

        //ICommand Interface Memembers

        /// <summary>
        /// Command: make a dependency property so it can be DataBound.
        /// </summary>
        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register(
                "Command",                              // property name
                typeof(ICommand),                       // datatype
                typeof(IndentCommandSlider),            // type that ownes the property (slider)
                new PropertyMetadata((ICommand)null,                //  optional property settings
                new PropertyChangedCallback(CommandChanged)));      //  optional callback for validation (see below)

        public ICommand Command
        {
            get { return (ICommand)GetValue(CommandProperty); }
            set { SetValue(CommandProperty, value); }
        }

        /// <summary>
        /// CommandTarget: make a dependency property so it can be DataBound
        /// </summary>
        public static readonly DependencyProperty CommandTargetProperty =
            DependencyProperty.Register(
                "CommandTarget",                        // property name
                typeof(IInputElement),                  // datatype
                typeof(IndentCommandSlider),            // type that ownes the property (slider)
                new PropertyMetadata((IInputElement)null));         //  optional property settings

        public IInputElement CommandTarget
        {
            get { return (IInputElement)GetValue(CommandTargetProperty); }
            set { SetValue(CommandTargetProperty, value); }
        }

        //make CommandParameter a dependency property so it can be DataBound
        public static readonly DependencyProperty CommandParameterProperty =
            DependencyProperty.Register(
                "CommandParameter",                     // property name
                typeof(object),                         // datatype
                typeof(IndentCommandSlider),            // type that ownes the property (slider)
                new PropertyMetadata((object)null));                //  optional property settings

        public object CommandParameter
        {
            get { return (object)GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        }

        #endregion // Dependency properties

        /// <summary>
        /// Command dependency property change callback from Command property above.
        /// </summary>
        /// <param name="d"></param>
        /// <param name="e"></param>
        private static void CommandChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            IndentCommandSlider cs = (IndentCommandSlider)d;
            cs.HookUpCommand((ICommand)e.OldValue, (ICommand)e.NewValue);
        }

        /// <summary>
        /// Add a new command to the Command Property.  Remove any old handlers first.
        /// </summary>
        /// <param name="oldCommand"></param>
        /// <param name="newCommand"></param>
        private void HookUpCommand(ICommand oldCommand, ICommand newCommand)
        {
            EventHandler handler;

            //if oldCommand is not null, then we need to remove the handlers
            if (oldCommand != null)
            {
                handler = CanExecuteChanged;
                oldCommand.CanExecuteChanged -= handler;
            }

            handler = new EventHandler(CanExecuteChanged);
            canExecuteChangedHandler = handler;
            if (newCommand != null)
            {
                newCommand.CanExecuteChanged += canExecuteChangedHandler;
            }
        }

        /// <summary>
        /// This method supports to the CanExecuteChanged event 
        ///   supported by the ICommand Interface.  Method calls the CanExecute method of ICommand to determine
        ///   the state of the command.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CanExecuteChanged(object sender, EventArgs e)
        {
            if (this.Command != null)
            {
                RoutedCommand command = this.Command as RoutedCommand;

                // if RoutedCommand
                if (command != null)
                {
                    if (command.CanExecute(CommandParameter, CommandTarget))
                    {
                        this.IsEnabled = true;
                    }
                    else
                    {
                        this.IsEnabled = false;
                    }
                }
                // if not RoutedCommand
                else
                {
                    if (Command.CanExecute(CommandParameter))
                    {
                        this.IsEnabled = true;
                    }
                    else
                    {
                        this.IsEnabled = false;
                    }
                }
            }
        }

        /// <summary>
        ///  If Indent Text command is defined, then a change to the slider value will invoke your logic.
        /// </summary> 
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected override void OnValueChanged(double oldValue, double newValue)
        {
            base.OnValueChanged(oldValue, newValue);

            if (this.Command != null)
            {
                RoutedCommand command = Command as RoutedCommand;

                if (command != null)
                {
                    command.Execute(newValue, CommandTarget);
                }
                else
                {
                    ((ICommand)Command).Execute(CommandParameter);
                }
            }
        }

        //keep a static copy of the handler so it doesn't get garbage collected.
        private static EventHandler canExecuteChangedHandler;
    }
}

