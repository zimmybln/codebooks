using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows;

namespace WpfAppRuler
{
    public class CommandSlider : Slider, ICommandSource
    {
        public CommandSlider()
            : base()
        {
        }

        #region Dependency Properties  //  WPF uses dependency properties to support change notification and dynamic value resolution.

        //ICommand Interface Memembers

        /// <summary>
        /// Command: make a dependency property so it can be DataBound.
        /// </summary>
        public static readonly DependencyProperty CommandProperty =
            DependencyProperty.Register(
                "Command",                          // property name
                typeof(ICommand),                   // datatype
                typeof(CommandSlider),              // type that ownes the property (slider)
                new PropertyMetadata((ICommand)null,                //  optional property settings
                new PropertyChangedCallback(CommandChanged)));      //  optional callback for validation (see below)

        // The get/set verbs are wrappers - WPF uses GetValue and SetValue for dependency properties.
        // Because the get/set verbs are just wrappers - you cannot add any additional code to these properties.
        public ICommand Command
        {
            get {  return (ICommand)GetValue(CommandProperty);  }
            set {  SetValue(CommandProperty, value); }
        }

        /// <summary>
        /// CommandTarget: make a dependency property so it can be DataBound.
        /// </summary>
        public static readonly DependencyProperty CommandTargetProperty =
            DependencyProperty.Register(
                "CommandTarget",                    // property name
                typeof(IInputElement),              // datatype
                typeof(CommandSlider),              // type that ownes the property (slider)
                new PropertyMetadata((IInputElement)null));         //  optional property settings

        public IInputElement CommandTarget
        {
            get {  return (IInputElement)GetValue(CommandTargetProperty); }
            set {  SetValue(CommandTargetProperty, value);  }
        }

        /// <summary>
        /// CommandParameter: make a dependency property so it can be DataBound.
        /// </summary>
        public static readonly DependencyProperty CommandParameterProperty =
            DependencyProperty.Register(
                "CommandParameter",                 // property name
                typeof(object),                     // datatype
                typeof(CommandSlider),              // type that ownes the property (slider)
                new PropertyMetadata((object)null));            //  optional property settings

        public object CommandParameter
        {
            get {  return (object)GetValue(CommandParameterProperty);  }
            set {  SetValue(CommandParameterProperty, value);  }
        }

        #endregion // Dependency Properties

        /// <summary>
        /// Command dependency property: establish callback as specified in Command property above:
        /// "new PropertyChangedCallback(CommandChanged)" 
        /// The actual deed is done in HoopUpCommand below.
        /// </summary>
        /// <param name="d"></param>
        /// <param name="e"></param>
        private static void CommandChanged(DependencyObject d,
            DependencyPropertyChangedEventArgs e)
        {
            CommandSlider cs = (CommandSlider)d;
            cs.HookUpCommand((ICommand)e.OldValue, (ICommand)e.NewValue);
        }

        /// <summary>
        /// Add a new command to the Command Property.  Remove any old handlers first.
        /// </summary>
        /// <param name="oldCommand"></param>
        /// <param name="newCommand"></param>
        private void HookUpCommand(ICommand oldCommand, ICommand newCommand)
        {
            EventHandler handler;

            // If oldCommand is not null, then we need to remove the handler.
            if (oldCommand != null)
            {
                handler = CanExecuteChanged;
                oldCommand.CanExecuteChanged -= handler;
            }

            handler = new EventHandler(CanExecuteChanged);
            canExecuteChangedHandler = handler;
            if (newCommand != null)
            {
                newCommand.CanExecuteChanged += canExecuteChangedHandler;
            }
        }

        /// <summary>
        /// The ICommand Interface requires that we support the CanExecuteChanged event. 
        /// This method calls the CanExecute method of ICommand to set the enabled state of the command.
        /// For this application - I don't want the sliders enabled if the focus is not set to the RichText editor.
        /// Locate the XAML definition for this slider (local:CommandSlider) in rtbRuler.xaml and you will see
        /// that the CommandTarget is set to RichTextBox1 (Binding ElementName=RichTextBox1).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CanExecuteChanged(object sender, EventArgs e)
        {
            if (this.Command != null)
            {
                RoutedCommand command = this.Command as RoutedCommand;

                // if RoutedCommand
                if (command != null)
                {
                    if (command.CanExecute(CommandParameter, CommandTarget))
                    {
                        this.IsEnabled = true;
                    }
                    else
                    {
                        this.IsEnabled = false;
                    }
                }
                // if not RoutedCommand
                else
                {
                    if (Command.CanExecute(CommandParameter))
                    {
                        this.IsEnabled = true;
                    }
                    else
                    {
                        this.IsEnabled = false;
                    }
                }
            }
        }

        /// <summary>
        /// If Left Margin command is defined, then a change to the slider value will invoke your logic.
        /// This method is generic but you can jump in here and write whatever custom code you need.
        /// The XAML control is bound to this interface so it doesn't matter if the control value 
        /// was changed by the user or by the program.  It all flows through here.  Sanity!
        /// </summary>
        /// <param name="oldValue"></param>
        /// <param name="newValue"></param>
        protected override void OnValueChanged(double oldValue, double newValue)
        {
            base.OnValueChanged(oldValue, newValue);

            if (this.Command != null)
            {
                RoutedCommand rteCommand = Command as RoutedCommand;

                if (rteCommand != null)
                {
                    rteCommand.Execute(newValue, CommandTarget);
                }
                else
                {
                    ((ICommand)Command).Execute(CommandParameter);
                }
            }
        }

        //keep a static copy of the handler so it doesn't get garbage collected.
        private static EventHandler canExecuteChangedHandler;
    }
}
