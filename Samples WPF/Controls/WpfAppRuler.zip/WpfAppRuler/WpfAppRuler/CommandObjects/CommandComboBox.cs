using System;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;

namespace WpfAppRuler 
{
	public class CommandComboBox : ComboBox, ICommandSource
	{

    #region Dependency Properties  //  WPF uses dependency properties to support change notification and dynamic value resolution.

        //ICommand Interface Memembers

        // These special WPF properties are refered to as dependency properties because the actual value of the property 
        //   DEPENDS on multiple providers, each with its own priority.

        /// <summary>
        /// Command: make a dependency property so it can be databound.
        /// </summary>
		public static readonly DependencyProperty CommandProperty =
				DependencyProperty.Register(
						"Command",                      // property name
						typeof( ICommand ),             // datatype
						typeof( CommandComboBox ),      // type that ownes the property (combobox)
						new PropertyMetadata( (ICommand)null,               //  optional property settings
						new PropertyChangedCallback( CommandChanged ) ) );  //  optional callback for validation (see below)

        public ICommand Command
        {
            get { return GetValue(CommandProperty) as ICommand; }           // notice use of GetValue in property wrapper.
            set { SetValue(CommandProperty, value); }                       // notice use of SetValue in property wrapper.
        } 

        /// <summary>
        /// CommandTarget: make a dependency property so it can be databound.
        /// </summary>
		public static readonly DependencyProperty CommandTargetProperty =
				DependencyProperty.Register(
						"CommandTarget",                // property name 
						typeof( IInputElement ),        // datatype
						typeof( CommandComboBox ),      // type that ownes the property (combobox)
						new PropertyMetadata( (IInputElement)null ) );      // optional property settings

        public object CommandParameter
        {
            get { return GetValue(CommandParameterProperty); }
            set { SetValue(CommandParameterProperty, value); }
        } 

        /// <summary>
        /// CommandParameter: make a dependency property so it can be databound.
        /// </summary>
		public static readonly DependencyProperty CommandParameterProperty =
				DependencyProperty.Register(
						"CommandParameter",             // property name
						typeof( object ),               // datatype
						typeof( CommandComboBox ),      // type that ownes the property (combobox)
						new PropertyMetadata( (object)null ) );             // optional property settings

        public IInputElement CommandTarget
        {
            get { return GetValue(CommandTargetProperty) as IInputElement; }
            set { SetValue(CommandTargetProperty, value); }
        }

    #endregion  // Dependency Properties

		public CommandComboBox()
		{
			//this.uiElementInput = new UIElementInput( this );  // this logic is not implemented at this time.
		} 

		public bool UseSelectedValueAsCommandParameter
		{
			get { return this.useSelectedValueAsCommandParameter; }
			set { this.useSelectedValueAsCommandParameter = value; }
		}

        /// <summary>
        /// This is the validation callback routine specified when creating 
        ///   the 'Command' dependency property above.
        /// </summary>
        /// <param name="d"></param>
        /// <param name="e"></param>
        private static void CommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            CommandComboBox comboBox = d as CommandComboBox;
            comboBox.HookUpCommand(e.OldValue as ICommand, e.NewValue as ICommand);
        }

        /// <summary>
        /// Add a new command to the command property.  The Command property cannot be overwritten when 
        ///   a new command is added, because the event handlers associated with the previous command, 
        ///   if there was one, must be removed first. (Comment from MSDN ICommandSource Interface page.)
        /// </summary>
        /// <param name="oldCommand"></param>
        /// <param name="newCommand"></param>
        private void HookUpCommand(ICommand oldCommand, ICommand newCommand)
        {
            EventHandler handler;

            // if oldCommand is not null, then we need to remove the handlers.
            if (oldCommand != null)
            {
                handler = CanExecuteChanged;
                oldCommand.CanExecuteChanged -= handler;
            }

            handler = new EventHandler(CanExecuteChanged);
            canExecuteChangedHandler = handler;
            if (newCommand != null)
            {
                newCommand.CanExecuteChanged += canExecuteChangedHandler;
            }
        }

        /// <summary>
        /// This method supports to the CanExecuteChanged event 
        ///   supported by the ICommand Interface.  Method calls the CanExecute method of ICommand to determine
        ///   the state of the command.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CanExecuteChanged(object sender, EventArgs e)
        {
            if (Command == null)
            {
                return;
            }

            RoutedCommand routedCommand = Command as RoutedCommand;
            if (routedCommand != null)
            {
                IsEnabled = routedCommand.CanExecute(CommandParameter, CommandTarget);
            }
            else
            {
                IsEnabled = Command.CanExecute(CommandParameter);
            }
        } 

        /// <summary>
        /// This is similar to OnValueChanged in the slider logic.  The combobox
        /// is set to respond to OnCommandExecute and OnSelectionChanged.
        /// </summary>
		protected virtual void OnCommandExecute()
		{
			ICommand command = Command;

			if ( command == null )
			{
				return;
			}

			if ( UseSelectedValueAsCommandParameter )
			{
				CommandParameter = SelectedValue;
			}

			if ( command is RoutedCommand )
			{
				( (RoutedCommand)command ).Execute( CommandParameter, CommandTarget );
			}
			else
			{
				command.Execute( CommandParameter );
			}
		} 

        /// <summary>
        /// The combobox is set to repond to OnCommandChange and OnSelectionChanged.
        /// </summary>
        /// <param name="e"></param>
		protected override void OnSelectionChanged( SelectionChangedEventArgs e )
		{
			base.OnSelectionChanged( e );

			OnCommandExecute();
		}

		//private readonly UIElementInput uiElementInput;
		private bool useSelectedValueAsCommandParameter = true;

        //keep a static copy of the handler so it doesn't get garbage collected.
		private static EventHandler canExecuteChangedHandler;

	} 
} 