﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Configuration;
using System.Diagnostics;
using System.Text;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;
using System.Resources;
using System.Windows.Media.Imaging;
using WPF.JoshSmith.ServiceProviders.UI;

namespace WpfAppRuler
{
    /// <summary>
    /// Right now this dialog only does FontFamily and Font Color.  
    /// I intend to add Font Decorators in the future.
    /// Credit:  This class was very (very!) closely based on Josh Smith's 
    ///         'Drag and Drop Items in a Wpf ListView' project on the CodeProject Web site.
    /// </summary>
    public partial class FontStyleDlg : System.Windows.Window
    {
        ListViewDragDropManager<SysFonts> dragMgr;
        ListViewDragDropManager<SysFonts> dragMgr2;

        private ObservableCollection<SysFonts> ocSlctFonts;

        public FontStyleDlg()
        {
            InitializeComponent();
            this.Loaded += FontStyleDlg_Loaded;

            SolidColorBrush foreground = System.Windows.Media.Brushes.Black;
            System.Windows.Media.Brush brush = foreground;

            PopulateFontColorCombo(brush);
        }

        #region FontStyleDlg_Loaded

        /// <summary>
        /// Give the ListViews an ObservableCollection of Font 
        /// as a data source.  Note, the ListViewDragManager MUST
        /// be bound to an ObservableCollection, where the collection's
        /// type parameter matches the ListViewDragManager's type
        /// parameter (in this case, both have a type parameter of SysFont).
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void FontStyleDlg_Loaded(object sender, RoutedEventArgs e)
        {
            ocSlctFonts = SysFonts.CreateSlctFonts();
            this.SlctFontLstVw.ItemsSource = ocSlctFonts;

            this.SysFntLstVw.Items.Clear();
            ObservableCollection<SysFonts> ocSysFonts = SysFonts.CreateFonts();
            this.SysFntLstVw.ItemsSource = ocSysFonts;

            // This is all that you need to do, in order to use the ListViewDragManager.
            this.dragMgr = new ListViewDragDropManager<SysFonts>(this.SysFntLstVw);
            this.dragMgr2 = new ListViewDragDropManager<SysFonts>(this.SlctFontLstVw);

            // See Josh Smith's article on Drag-n-Drop with ListView for a full 
            // explanation of these next 5 values.
            this.dragMgr.ListView = this.SysFntLstVw;           //  ListView drag manager
            this.dragMgr.ShowDragAdorner = true;                //  Show drag adorner
            this.dragMgr.DragAdornerOpacity = 0.6;              //  Drag adorner Opacity
            this.SysFntLstVw.ItemContainerStyle = this.FindResource("ItemContStyle") as Style;  // Item containder style
            this.dragMgr.ProcessDrop += dragMgr_ProcessDrop;    //  Use custom drop logic

            // Hook up events on both ListViews to that we can drag-drop
            // items between them.
            this.SysFntLstVw.DragEnter += OnListViewDragEnter;
            this.SlctFontLstVw.DragEnter += OnListViewDragEnter;
            this.SysFntLstVw.Drop += OnListViewDrop;
            this.SlctFontLstVw.Drop += OnListViewDrop;
        }
        #endregion
        
        #region FontColorLogic

        /// <summary>
        /// This is code that I added to Josh's logic to populate the color patch list box
        /// </summary>
        /// <param name="foreground"></param>
        void PopulateFontColorCombo(System.Windows.Media.Brush foreground)
        {
            int i = 0;
           
            // Fill combobox with all known named colors
            for (i = 0; i < KnownColor.ColorNames.Length; i++)
            {
                TextColorListBox.Items.Add(new ColorComboBoxItem(
                    KnownColor.ColorNames[i],
                    (SolidColorBrush)KnownColor.ColorTable[KnownColor.ColorNames[i]]
                ));
            }

            // Look for and display incoming color
            string colorName = "Black";  // Will use black if incoming color is not a known named color

            if (foreground is SolidColorBrush)
            {
                System.Windows.Media.Brush brush = foreground as SolidColorBrush;
                for (i = 0; i < TextColorListBox.Items.Count; i++)
                {
                    if ((TextColorListBox.Items[i] as ColorComboBoxItem).Brush == brush)
                    {
                        colorName = (TextColorListBox.Items[i] as ColorComboBoxItem).ToString();
                    }
                }
            }
        }

        /// <summary>
        /// Apply the selected color form this ListBox to the current selected font in the ListView.
        /// </summary>
        /// <param name="o"></param>
        /// <param name="args"></param>
        void TextColorSelected(object o, SelectionChangedEventArgs args)
        {
            if (TextColorListBox.SelectedItem != null)
            {
                if (SlctFontLstVw.SelectedItems.Count > 0)
                {
                    SysFonts slctFont = SlctFontLstVw.SelectedItem as SysFonts;

                    //  Get the selected SysFonts object from the FontStyle ListView.
                    ListViewItem slctFontFamily = (ListViewItem)SlctFontLstVw.ItemContainerGenerator.ContainerFromItem(slctFont);

                    if (slctFontFamily != null)
                    {
                        // Get the selected object from the Known Colors ListBox.
                        ColorComboBoxItem objFontStyle = TextColorListBox.SelectedItem as ColorComboBoxItem;

                        // Get the Known Color from the Color Item object.
                        slctFont.fontColor = objFontStyle.ToString();

                        // Apply that color to the SysFonts object.
                        BrushConverter brushConverter = new BrushConverter();
                        slctFontFamily.Foreground = brushConverter.ConvertFromString(objFontStyle.ToString()) as System.Windows.Media.Brush;

                        // Replace the FontFamily literal with the same text but painted with the new color.
                        slctFontFamily.FontFamily = new System.Windows.Media.FontFamily(slctFont.Name);

                        // Force a redraw of the FontStyle ListView to see the updated activity.
                        SlctFontLstVw.Items.Refresh();

                        // If the fontstyle entry in the listview is NOT checked - a default Black entry is created.
                        // If you don't want this to be the default action - just check the box in the ListView.
                        if (slctFont.UpdtOnly == false)
                        {
                            // Add a generic Black FontFamily to the FontStyle ListView.
                            SysFonts genericFont = new SysFonts("Black", slctFont.Name, true);
                            (this.SlctFontLstVw.ItemsSource as ObservableCollection<SysFonts>).Add(genericFont);
                        }
                    }
                    else
                    {
                        MessageBox.Show("Select a font to apply the color too. ", "FontStyle",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                }
            }
        }

        #endregion 

        #region DragDropLogic

        /// <summary>
        /// Performs custom drop logic for the Left (System Fonts) ListView.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void dragMgr_ProcessDrop(object sender, ProcessDropEventArgs<SysFonts> e)
        {
            // This shows how to customize the behavior of a drop.
            // Here we perform a swap, instead of just moving the dropped item.
            int higherIdx = Math.Max(e.OldIndex, e.NewIndex);
            int lowerIdx = Math.Min(e.OldIndex, e.NewIndex);

            if (lowerIdx < 0)
            {
                // The item came from the lower ListView
                // so just insert it.
                e.ItemsSource.Insert(higherIdx, e.DataItem);
            }
            else
            {
                // null values will cause an error when calling Move.
                // It looks like a bug in ObservableCollection to me.
                if (e.ItemsSource[lowerIdx] == null ||
                    e.ItemsSource[higherIdx] == null)
                    return;

                // The item came from the ListView into which
                // it was dropped, so swap it with the item
                // at the target index.
                e.ItemsSource.Move(lowerIdx, higherIdx);
                e.ItemsSource.Move(higherIdx - 1, lowerIdx);
            }

            // Set this to 'Move' so that the OnListViewDrop knows to 
            // remove the item from the other ListView.
            e.Effects = DragDropEffects.Move;
        }

        /// <summary>
        /// Handles the DragEnter event for both ListViews.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void OnListViewDragEnter(object sender, DragEventArgs e)
        {
            e.Effects = DragDropEffects.Move;
        }

        /// <summary>
        /// Handles the Drop event for both ListViews.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void OnListViewDrop(object sender, DragEventArgs e)
        {
            if (e.Effects == DragDropEffects.None)
                return;

            SysFonts FontStyleObj = e.Data.GetData(typeof(SysFonts)) as SysFonts;
            if (sender == this.SysFntLstVw)
            {
                if (this.dragMgr.IsDragInProgress)
                    return;

                // An item was dragged from the bottom ListView into the top ListView
                // so remove that item from the bottom ListView.
                (this.SlctFontLstVw.ItemsSource as ObservableCollection<SysFonts>).Remove(FontStyleObj);
            }
            else
            {
                if (this.dragMgr2.IsDragInProgress)
                    return;

                // An item was dragged from the top ListView into the bottom ListView
                // so remove that item from the top ListView.
                (this.SysFntLstVw.ItemsSource as ObservableCollection<SysFonts>).Remove(FontStyleObj);
            }
        }

        #endregion 

        /// <summary>
        /// Cancel the dialog - any activity is lost!!!
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CancelSlctFont_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = true;
        }

        /// <summary>
        /// Save FontListView to App.Config file and end the dialog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void SaveSlctFont_Click(object sender, RoutedEventArgs e)
        {
            // Array of string to hold the font key values from AppSettings.
            List<string> fontKeys = new List<string>();

            // Get the configuration file.
            System.Configuration.Configuration configuration =
                    ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

            // This routine just clears out all the existing AppConfig font entries
            // and starts over from scratch.  There are not that many entires and 
            // the code is cleaner this way.  Make a list of the font keys in this
            // foreach loop and use the list to delete them in the next foreach loop.
            foreach (string key in ConfigurationManager.AppSettings.AllKeys)
            {
                if (key.StartsWith("Font", StringComparison.CurrentCultureIgnoreCase))
                {
                    string str = ConfigurationManager.AppSettings[key];
                    fontKeys.Add(key);
                }
            }
            
            foreach (string xkey in fontKeys)
            {
                configuration.AppSettings.Settings.Remove(xkey);
            }

            // Now - create brand new AppSettings for ALL font values.
            Int32 iCntr = 1;
            foreach (SysFonts myFont in ocSlctFonts)
            {
                string FontName = myFont.Name;
                string FontColor = myFont.fontColor;

                // Create the AppSetting values.
                string AppString = @"Color=" + FontColor + @",FontFamily=" + FontName; 
                string xKey = String.Format("Font{0:d}", iCntr);

                // Write the AppSettings entry to the configuration file.
                configuration.AppSettings.Settings.Add(xKey, AppString);

                iCntr++;
            }

            // Save the new configuration settings.
            configuration.Save(ConfigurationSaveMode.Modified, true);

            // Flush the appSettings cache - this forces a re-read from the config file 
            // the next time the fonts are accessed. 
            ConfigurationManager.RefreshSection("appSettings");

            // End the dialog and return to the RichTextBox window.
            DialogResult = true;
        }
    }
}
