﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.IO;
using Microsoft.Win32;
using System.Configuration;
using System.Text.RegularExpressions;

namespace WpfAppRuler
{
    /// <summary>
    /// Main windows routine for rtbRuler.xaml
    /// </summary>
    public partial class rtbRuler : Window
    {
        static double RightMarginDefaultValue = 252.0;
        static double RightMarginUpperLimit = 258.0;

        public rtbRuler()
        {
            InitializeComponent();

            richTextBox1.AddHandler(RichTextBox.MouseLeftButtonUpEvent, new RoutedEventHandler(RichTextMouseClick), true);

            //  Initialize the FontFamily ToolBar ComboBox with the font info from AppSettings in App.Config.
            FillFontComboBox();
        }

        private void element_MouseEnter(object sender, MouseEventArgs e)
        {
            ((Button)sender).Background = new
            SolidColorBrush(Colors.Cornsilk);
        }

        private void element_MouseLeave(object sender, MouseEventArgs e)
        {
            ((Button)sender).Background = null;
        }

        // Font Decorators are handled by XAML code:
        //  EditingCommands.ToggleItalic  
        //  EditingCommands.ToggleUnderline and
        //  EditingCommmands.ToggleBold.

        /// <summary>
        /// Fairly standard Open Document Dialog logic.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdOpen_Click(object sender, RoutedEventArgs e)
        {

            OpenFileDialog openFile = new OpenFileDialog();
            openFile.Filter = "XAML Files (*.xaml)|*.xaml|RichText Files (*.rtf)|*.rtf|All Files (*.*)|*.*";

            if (openFile.ShowDialog() == true)
            {
                // Create a TextRange around the entire document.
                TextRange documentTextRange = new TextRange(
                    richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);

                using (FileStream fs = File.Open(openFile.FileName, FileMode.Open))
                {
                    if (System.IO.Path.GetExtension(openFile.FileName).ToLower() == ".rtf")
                    {
                        documentTextRange.Load(fs, DataFormats.Rtf);
                    }
                    else
                    {
                        documentTextRange.Load(fs, DataFormats.Xaml);
                    }
                }
            }
        }

        /// <summary>
        /// Fairly standard Save Document Dialog logic.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdSave_Click(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFile = new SaveFileDialog();
            saveFile.Filter = "XAML Files (*.xaml)|*.xaml|RichText Files (*.rtf)|*.rtf|All Files (*.*)|*.*";

            if (saveFile.ShowDialog() == true)
            {
                // Create a TextRange around the entire document.
                TextRange documentTextRange = new TextRange(
                    richTextBox1.Document.ContentStart, richTextBox1.Document.ContentEnd);

                // If this file exists, it's overwritten.
                using (FileStream fs = File.Create(saveFile.FileName))
                {
                    if (System.IO.Path.GetExtension(saveFile.FileName).ToLower() == ".rtf")
                    {
                        documentTextRange.Save(fs, DataFormats.Rtf);
                    }
                    else
                    {
                        documentTextRange.Save(fs, DataFormats.Xaml);
                    }
                }
            }
        }

        /// <summary>
        /// This is a dialog window for FontFamily and Color configuration.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void cmdFont_Click(object sender, RoutedEventArgs e)
        {
            FontStyleDlg dialog = new FontStyleDlg();
            dialog.ShowDialog();

            if (dialog.DialogResult.HasValue && dialog.DialogResult.Value)
            {
                // Get the configuration file.
                System.Configuration.Configuration configuration =
                  ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);

                FontsComboBox.Items.Clear();
                FillFontComboBox();
            }
            else
                MessageBox.Show("User clicked Cancel");
        }

        /// <summary>
        /// Fill the FontComboBox with values from the AppSettings (App.Config) values for this program.
        /// </summary>
        private void FillFontComboBox()
        {
            Regex exprFonts = new Regex(@"^Color[\=]{1}(?<xColor>[\s\w]{3,24}),FontFamily[\=]{1}(?<xFont>[\s\w]{3,26})", RegexOptions.IgnoreCase);
            MatchCollection xmlElements;
            string strColor;
            string strFontFamily;

            foreach (string key in ConfigurationManager.AppSettings.AllKeys)
            {
                //  If the AppSetting key starts with Font - it's value is one of the ComboBox FontFamily settings.
                if (key.StartsWith("Font", StringComparison.CurrentCultureIgnoreCase))
                {
                    string strAppSettings = ConfigurationManager.AppSettings[key];
                    strColor = "";
                    strFontFamily = "";

                    // Extract the FontFamily and Known Color from the AppSettings value parameter.
                    xmlElements = exprFonts.Matches(strAppSettings);
                    foreach (Match tempVar_xmlElem in xmlElements)
                    {
                        strColor = tempVar_xmlElem.Groups[1].Value;
                        strFontFamily = tempVar_xmlElem.Groups[2].Value;
                    }

                    // FontComboBoxItem will return a WPF panel layout type
                    // With the FontFamily and Known Color to be added to
                    // the FontComboBox.
                    FontsComboBox.Items.Add(new FontComboBoxItem( strFontFamily,
                        (SolidColorBrush)KnownColor.ColorTable[strColor]));
                }
            }

            FontsComboBox.SelectedIndex = 0;
        }

        private void cmdNew_Click(object sender, RoutedEventArgs e)
        {
            richTextBox1.Document = new FlowDocument();
        }

        /// <summary>
        /// Work back up the document chain and see if the element (usually a paragraph)
        /// is part of a list.
        /// </summary>
        /// <param name="element"></param>
        /// <returns></returns>
        private List FindListAncestor(DependencyObject element)
        {
            while (element != null)
            {
                List list = element as List;
                if (list != null)
                {
                    return list;
                }

                //  Get the parent for the current element
                element = LogicalTreeHelper.GetParent(element);
            }

            return null;
        }


        /// <summary>
        /// When the mouse is clicked in the richtextbox, it will leave the edit carat at
        ///   the mouse point position.  This routine will first determine the Font information
        ///   at the carat location and then retrieve the paragraph information that is 
        ///   relevant to the slider controls.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void RichTextMouseClick(object sender, RoutedEventArgs e)
        {
            // Get the paragraph the carat is now located in.
            TextPointer pointer = richTextBox1.Selection.Start;
            Paragraph rtbParagraph = pointer.Paragraph;

            Double RightMargin;
            SolidColorBrush currentFontColor = null;

            // Determine the FontFamily at the current carat location
            string selectedFont = richTextBox1.Selection.GetPropertyValue(RichTextBox.FontFamilyProperty).ToString();

            // Determine the Foreground Font Color at the current carat location.
            object selectedForeground =  richTextBox1.Selection.GetPropertyValue(RichTextBox.ForegroundProperty);

            // If no color was selected (the carat is on white space) - make Black the default.
            if (selectedForeground == DependencyProperty.UnsetValue || selectedForeground == null)
            {
                currentFontColor = (SolidColorBrush)KnownColor.ColorTable["Black"];
            }
            else
            {
                //  Store the font color in a SolidColorBrush.
                currentFontColor = selectedForeground as SolidColorBrush;
            }

            //  Find the font in the toolbar font combobox.
            Boolean FontFamilyFound = false;
            foreach (FontComboBoxItem FontItem in FontsComboBox.Items)
            {
                String FontName = FontItem.ToString();
                if (FontName == selectedFont)
                {
                    // It's the correct FontFamily - now check the color.
                    if (FontItem.Brush.Color == currentFontColor.Color)
                    {
                        //  Make it viewable in the toolbar combobox.
                        FontsComboBox.SelectedIndex = FontsComboBox.Items.IndexOf(FontItem);
                        FontFamilyFound = true;
                        break;
                    }
                }
            }

            //  If the richtext carat font is not found in the combobox, it's ok.
            //  The combobox fonts may have changed since the document was created or the 
            //  document may have been initially created using another program.
            //  No matter - let's just get the FontFamily name and put it in the combobox.
            if (FontFamilyFound == false)
            { 
                //  Add the unknown FontFamily and color to the combobox.
                FontsComboBox.Items.Add(new FontComboBoxItem(selectedFont,
                        currentFontColor));
                
                //  Now find it and make it the selected (viewed) FontFamily.
                foreach (FontComboBoxItem FontItem in FontsComboBox.Items)
                {
                    String FontName = FontItem.ToString();
                    if (FontName == selectedFont)
                    {
                        FontsComboBox.SelectedIndex = FontsComboBox.Items.IndexOf(FontItem);
                        break;
                    }
                }
            }

            //  Set the FontSize slider to the paragraph font size.
            FontSizeSlider.Value = rtbParagraph.FontSize;

            //  If a lineheight exists for the paragraph - us it.
            //  Else - use a default value of 12 as the slider value.
            if (Double.IsNaN(rtbParagraph.LineHeight))
            { LineSpaceSlider.Value = 12.0; }
            else
            { LineSpaceSlider.Value = rtbParagraph.LineHeight; }


            // Look up the chain and see if this paragraph is in a list.
            Thickness objMargin;
            List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

            if (list != null)
            {
                //  Store the current list margins in a Thickness varialbe type.
                objMargin = list.Margin;
            }
            else
            {
                //  Store the current paragraphs margins in a Thickness variable type.
                objMargin = rtbParagraph.Margin;
            }

            //  If a right margin exists - store it in the variable RightMargin for the moment.
            if (list != null)  // the edit carat is on a list item.

                if (Double.IsNaN(list.Margin.Right))
                    RightMargin = 0.0;
                else
                    RightMargin = list.Margin.Right;
            else
                if (Double.IsNaN(rtbParagraph.Margin.Right))
                    RightMargin = 0.0; 
                else
                    RightMargin = objMargin.Right; 

            //  If a left margin DOES NOT exist - use these defaults for these 3 sliders.
            if (Double.IsNaN(objMargin.Left))
            {
                LeftMarginSlider.Value = 0.0;
                RightMarginSlider.Value = RightMarginDefaultValue;      // defined as a static value above.
                IndentSlider.Value = 0.0;

                objMargin.Left = 0.0;
                objMargin.Right = 0.0;
                if (list != null)
                {
                    objMargin.Top = 6.0;
                    objMargin.Bottom = 6.0;
                }
                else
                {
                    objMargin.Top = 17.0;
                    objMargin.Bottom = 14.0;
                }

                if (list != null)
                    list.Margin = objMargin;
                else
                    rtbParagraph.Margin = objMargin;
            }
            else
            {
                LeftMarginSlider.Value = objMargin.Left;

                // Make sure the text indent is based on a displacement from the paragraphs left margin.
                IndentSlider.Value = rtbParagraph.TextIndent + objMargin.Left;

                //  The left margin slider value moved from right-left instead of left-right,
                //  so the routine needs to start with the sliders highest allowed value and subtract the 
                //  slider current value.  If the right margin slider is set to 240 - the right margin value
                //  will be 258-240 = 18.
                RightMarginSlider.Value = RightMarginUpperLimit - RightMargin;
            }
        }

        //  These are static placeholders for the CommandSliders.
        public static RoutedCommand LeftMarginUpdtCmnd = new RoutedCommand();
        public static RoutedCommand IndentUpdtCmnd = new RoutedCommand();
        public static RoutedCommand RightMarginUpdtCmnd = new RoutedCommand();
        public static RoutedCommand FontSizeUpdtCmnd = new RoutedCommand();
        public static RoutedCommand LineSpaceUpdtCmnd = new RoutedCommand();

    #region Slider Controls

        /// <summary>
        /// If the command target is the RichTextBox, changes the left margin to
        ///   the value passed in through the Command Parameter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void LeftSliderUpdateExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;
            double SliderValue = (double)e.Parameter;

            if (source != null)
            {
                if (e.Parameter != null)
                {
                    try
                    {
                        // Look up the chain and see if this paragraph is in a list.
                        List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

                        if (list != null)
                        {
                            //  Store the current list margins in a Thickness varialbe type.
                            Thickness objMargin = list.Margin;
                            list.Margin = new Thickness((int)SliderValue, 8, objMargin.Right, 8);
                        }
                        else
                        {
                            //  Store the current paragraphs margins in a Thickness variable type.
                            TextPointer pointer = richTextBox1.Selection.Start;
                            Paragraph rtbParagraph = pointer.Paragraph;
                            rtbParagraph.Margin = new Thickness((int)SliderValue, 12, rtbParagraph.Margin.Right, 17);
                        }

                        IndentSlider.Value = LeftMarginSlider.Value;
                    }
                    catch (Exception ex)
                    {              
                        MessageBox.Show("Left Slider failed: " + " \n\r\n\r" + ex, "Slider", 
                                                    MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        /// <summary>
        /// If the command target is the RichTextBox, changes the margin to that 
        /// of the value passed in through the Command Parameter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void IndentSliderUpdateExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;
            double SliderValue = (double)e.Parameter;

            if (source != null)
            {
                if (e.Parameter != null)
                {
                    try
                    {
                        // Look up the chain and see if this paragraph is in a list.
                        List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

                        if (list != null)
                        {
                            //  Don't do anything!  We don't want to use the IndentSlider with the List values.
                        }
                        else
                        {
                            //  Store the current paragraphs margins in a Thickness variable type.
                            TextPointer pointer = richTextBox1.Selection.Start;
                            Paragraph rtbParagraph = pointer.Paragraph;
                            rtbParagraph.TextIndent = ((int)SliderValue) - rtbParagraph.Margin.Left;
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Indent Slider failed: " + " \n\r\n\r" + ex, "Slider", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        /// <summary>
        /// If the command target is the RichTextBox, change the margin to that
        /// of the value passed in through the command parameter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void RightSliderUpdateExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;
            double SliderValue = (double)e.Parameter;

            Int32 RightMargin = (int)RightMarginUpperLimit - (int)SliderValue;

            if (RightMargin < 0) { RightMargin = 0; }

            if (SliderValue > RightMarginDefaultValue) 
            { 
                RightMarginSlider.Value = RightMarginDefaultValue;
                SliderValue = RightMarginDefaultValue;
            }

            if (source != null)
            {
                if (e.Parameter != null)
                {
                    try
                    {
                         // Look up the chain and see if this paragraph is in a list.
                         List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

                         if (list != null)
                         {
                             //  Store the current list margins in a Thickness varialbe type.
                             Thickness objMargin = list.Margin;
                             list.Margin = new Thickness(list.Margin.Left, 8, RightMargin, 8);
                         }
                         else
                         {
                             //  Store the current paragraphs margins in a Thickness variable type.
                             TextPointer pointer = richTextBox1.Selection.Start;
                             Paragraph rtbParagraph = pointer.Paragraph;
                             rtbParagraph.Margin = new Thickness(rtbParagraph.Margin.Left, 12, RightMargin, 17);
                         }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Slider failed: " + " \n\r\n\r" + ex, "Slider", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        /// <summary>
        /// If the command target is the RichTextBox, changes the fontsize to that
        ///   of the value passed in through the Command Parameter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void FontSliderUpdateExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;

            if (source != null)
            {
                if (e.Parameter != null)
                {
                    try
                    {
                        double SliderValue = (double)e.Parameter;
                        if ((int)SliderValue > 10 && (int)SliderValue <= 64)
                        {
                            // Look up the chain and see if this paragraph is in a list.
                            List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

                            if (list != null)
                            {
                                // this instruction increases the font size of the bullet or number
                                list.FontSize = (int)SliderValue;

                                // Now we have to step through each listItem and Paragraph.
                                foreach (ListItem listItem in list.ListItems)
                                {
                                    foreach (Paragraph listParagraph in listItem.Blocks)
                                    {
                                        listParagraph.FontSize = (int)SliderValue;
                                    }
                                }

                                if (Double.IsNaN(list.LineHeight))
                                { }
                                else
                                { LineSpaceSlider.Value = list.LineHeight; }
                            }
                            else
                            {
                                TextPointer pointer = richTextBox1.Selection.Start;
                                Paragraph rtbParagraph = pointer.Paragraph;
                                rtbParagraph.FontSize = (int)SliderValue;

                                if (Double.IsNaN(rtbParagraph.LineHeight))
                                { }
                                else
                                { LineSpaceSlider.Value = rtbParagraph.LineHeight; }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Font Slider failed: " + " \n\r\n\r" + ex, "Slider", 
                                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        /// <summary>
        /// If the command target is the RichTextBox, changes the LineHeight to that
        ///   of the value passed in through the Command Parameter
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void LineSpaceUpdateExecuted(object sender, ExecutedRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;

            if (source != null)
            {
                if (e.Parameter != null)
                {
                    try
                    {
                        double SliderValue = (double)e.Parameter;
                        if ((int)SliderValue > 16 && (int)SliderValue <= 42)
                        {
                            // Look up the chain and see if this paragraph is in a list.
                            List list = FindListAncestor(richTextBox1.Selection.Start.Parent);

                            if (list != null)
                            {
                                // Now we have to step through each listItem and Paragraph.
                                foreach (ListItem listItem in list.ListItems)
                                {
                                    foreach (Paragraph listParagraph in listItem.Blocks)
                                    {
                                        listParagraph.LineHeight = (int)SliderValue;
                                    }
                                }
                            }
                            else
                            {
                                TextPointer pointer = richTextBox1.Selection.Start;
                                Paragraph rtbParagraph = pointer.Paragraph;
                                rtbParagraph.LineHeight = (int)SliderValue;
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Line Space Slider failed: " + " \n\r\n\r" + ex, "Slider",
                                            MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        /// <summary>
        /// CanExecuteRoutedEvent Handler:  If the Command source is the RichTextBox, 
        ///   Then set CanExecute to true, otherwise, set it to false.
        ///   
        ///   This Event Handler is used by all the custom sliders:
        ///   XAML code is: Executed="######SliderUpdateExecuted" CanExecute="SliderUpdatesCanExecute" 
        ///   where ###### is the name of the individual custom slider.
        ///   
        ///   This short routine simply tells each one of the sliders that the RichTextBox is
        ///   'open for business' and the individual sliders can go live.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void SliderUpdatesCanExecute(object sender, CanExecuteRoutedEventArgs e)
        {
            RichTextBox source = sender as RichTextBox;

            if (source != null)
            {
                if (source.IsReadOnly)
                {
                    e.CanExecute = false;
                }
                else
                {
                    e.CanExecute = true;
                }
            }
        }

    #endregion // Slider Controls

        /// <summary>
        /// Apply the knew FontFamily and Known Color from the ToolBar ComboBox.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void ComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //Is Window initialized?
            if (!IsInitialized) return;

            FontComboBoxItem objFontFamily = FontsComboBox.SelectedValue as FontComboBoxItem;

            if (objFontFamily != null)
            {
                string FontFamily = objFontFamily.ToString();
                richTextBox1.Selection.ApplyPropertyValue(TextElement.FontFamilyProperty, new FontFamily(FontFamily));
                richTextBox1.Selection.ApplyPropertyValue(TextElement.ForegroundProperty, objFontFamily.Brush);
            }
        }

        private void richTextBox1_TextChanged(object sender, TextChangedEventArgs e)
        {
            // not used at this time.
        }

        /// <summary>
        /// These are the bottoms at the bottom of the RichText editor.  
        /// Notice the RoutedEventArgs parameter.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MailboxO_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = Cursors.No;
        }

        private void EMail_Click(object sender, RoutedEventArgs e)
        {
            this.Cursor = Cursors.No;
        }

    }
}
