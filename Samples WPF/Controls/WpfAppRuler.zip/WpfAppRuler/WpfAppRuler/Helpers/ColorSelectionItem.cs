﻿using System;
using System.Windows;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media;
using System.Collections;

namespace WpfAppRuler
{
    /// <summary>
    /// Define a item for chosing text color.
    /// </summary>
    public class ColorComboBoxItem : System.Windows.Controls.ListBoxItem
    {
        private SolidColorBrush _brush;
        private string          _colorName;

        /// <summary>
        /// Define a WPF panel type with a color swatch and the known color name.
        /// </summary>
        /// <param name="ColorName"></param>
        /// <param name="brush"></param>
        public ColorComboBoxItem(string ColorName, SolidColorBrush brush)
        {
            _brush = brush;

            StackPanel panel = new StackPanel();
            panel.Height       = double.NaN; // _height;
            panel.Orientation  = Orientation.Horizontal;

            Rectangle colorSwatch       = new Rectangle();
            colorSwatch.Height          = double.NaN; // _height;
            colorSwatch.Width           = 25;
            colorSwatch.Fill            = brush;
            colorSwatch.StrokeThickness = 1;
            colorSwatch.Stroke          = Brushes.DarkGray;
            colorSwatch.Margin          = new Thickness(1, 1, 1, 1);

            TextBlock colorName = new TextBlock();
            colorName.Text      = "  " + ColorName.Trim();
            colorName.Height    = double.NaN;       // auto height
            colorName.Width     = double.NaN;       // auto width
            colorName.Margin    = new Thickness(1, 1, 1, 1);

            panel.Children.Add(colorSwatch);
            panel.Children.Add(colorName);

            Content = panel;
            _colorName = ColorName;
        }

        /// <summary>
        /// Return the name of a color.
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _colorName;
        }

        /// <summary>
        /// Return the color as a solid colorBrush.
        /// </summary>
        public SolidColorBrush Brush
        {
            get
            {
                return _brush;
            }
        }
    }
}
