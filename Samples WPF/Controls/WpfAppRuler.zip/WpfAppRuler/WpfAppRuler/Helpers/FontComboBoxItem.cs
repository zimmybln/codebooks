﻿using System;
using System.Windows;
using System.Collections.Generic;
using System.Text;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using System.Collections;
using System.Globalization;

namespace WpfAppRuler
{
    /// <summary>
    /// Define a item for chosing text color.
    /// </summary>
    public class FontComboBoxItem : System.Windows.Controls.ListBoxItem
    {
        private SolidColorBrush _brush;
        private string _fontName;

        /// <summary>
        /// Define a WPF panel type with a color swatch and the FontFamily name.
        /// </summary>
        /// <param name="FontName"></param>
        /// <param name="brush"></param>
        public FontComboBoxItem(string FontName, SolidColorBrush brush)
        {
            _brush = brush;

            StackPanel panel = new StackPanel();
            panel.Height = double.NaN;    
            panel.Orientation = Orientation.Horizontal;

            Rectangle colorSwatch = new Rectangle();
            colorSwatch.Height = double.NaN; 
            colorSwatch.Width = 25;
            colorSwatch.Fill = brush;
            colorSwatch.StrokeThickness = 1;
            colorSwatch.Stroke = Brushes.DarkGray;
            colorSwatch.Margin = new Thickness(1, 1, 1, 1);

            TextBlock colorName = new TextBlock();
            colorName.Text = "  " + FontName.Trim();
            colorName.Foreground = brush;
            colorName.FontFamily = new System.Windows.Media.FontFamily(FontName);
            colorName.Height = double.NaN;       // default to auto height
            colorName.Width = double.NaN;        // default auto width
            colorName.Margin = new Thickness(1, 1, 1, 1);

            panel.Children.Add(colorSwatch);
            panel.Children.Add(colorName);

            Content = panel;
            _fontName = FontName;
        }

        /// <summary>
        /// return the name of a color
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return _fontName;
        }

        /// <summary>
        /// Return the color as a solid colorBrush
        /// </summary>
        public SolidColorBrush Brush
        {
            get
            {
                return _brush;
            }
        }

        public int CompareWithString(string value)
        {
            return String.Compare(_fontName, value, true, CultureInfo.InvariantCulture);
        }

        public bool RestrictToListedValues()
        {
            return true;     // Only available fonts may be selected
        }
    }
}
