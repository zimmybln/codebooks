﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace MainApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            Loaded += new RoutedEventHandler(MainWindow_Loaded);
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            progressIndicator.IsRunning = true;
            ThreadPool.QueueUserWorkItem(new WaitCallback(
                (object o) =>
                {
                    for (int i = 0; i <= 100; i++)
                    {
                        progressIndicator.Dispatcher.Invoke(new Action(
                            () =>
                            {
                                progressIndicator.Value = i;
                            }
                        ), null);

                        Thread.Sleep(100);
                    }

                    progressIndicator.Dispatcher.Invoke(new Action(
                        () =>
                        {
                            progressIndicator.IsRunning = false;
                        }
                    ), null);
                }
            ));
        }
    }
}
