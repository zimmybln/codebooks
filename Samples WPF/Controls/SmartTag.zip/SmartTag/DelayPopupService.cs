﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Threading;
using System.Windows;
using System.Windows.Input;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace SmartTag
{
    public class DelayPopupService
    {
        private DispatcherTimer timer = new DispatcherTimer();

        private UIElement target;
        private Popup smartTag;

        public DelayPopupService(UIElement element, Popup popup)
        {
            InitService(element, popup, TimeSpan.FromSeconds(0.4));
        }

        public DelayPopupService(UIElement element, Popup popup, TimeSpan delayInternal)
        {
            InitService(element, popup, delayInternal);
        }

        private void InitService(UIElement element, Popup popup, TimeSpan delayInternal)
        {
            target = element;
            smartTag = popup;

            smartTag.MouseMove += new MouseEventHandler(MyControl_MouseMove);
            smartTag.MouseLeave += new MouseEventHandler(myPopup_MouseLeave);
            target.MouseLeave += new MouseEventHandler(MyControl_MouseLeave);
            target.MouseMove += new MouseEventHandler(MyControl_MouseMove);
            timer.Tick += new EventHandler(timer_Tick);
            timer.Interval = delayInternal;           
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            timer.Stop();
            if ((!target.IsMouseOver) && (! smartTag.IsMouseOver))
                smartTag.IsOpen = false;
            else
            {
                if (!smartTag.IsOpen)
                    smartTag.IsOpen = true;
            }
        }

        private void myPopup_MouseLeave(object sender, MouseEventArgs e)
        {
            DelayShow(false);
        }
        private void MyControl_MouseLeave(object sender, MouseEventArgs e)
        {
            DelayShow(false);
        }
        private void MyControl_MouseMove(object sender, MouseEventArgs e)
        {
            if ((!smartTag.IsOpen) || (smartTag.Child.Opacity < 1.0))
                DelayShow(true);
        }

        private void DelayShow(Boolean ShowMe)
        {
            if (!ShowMe)
                smartTag.Child.Opacity = 0.5;
            else
                smartTag.Child.Opacity = 1.0;
                       
            timer.Start();
        }

    }
}
