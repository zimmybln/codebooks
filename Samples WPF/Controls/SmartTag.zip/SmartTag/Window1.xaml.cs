﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;
using System.Windows.Threading;

namespace SmartTag
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        private int click = 0;
      
        public Window1()
        {
            InitializeComponent();

            // Set up the delay service
            DelayPopupService delay = new DelayPopupService(MyButton, myPopup);
        }

       
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            click++;           
            MyResult.Text = "Button click: Total Clicked: " + click.ToString();
        }

        private void Close_Popup_Click(object sender, RoutedEventArgs e)
        {
            myPopup.IsOpen = false;
        }
       
    }
}
