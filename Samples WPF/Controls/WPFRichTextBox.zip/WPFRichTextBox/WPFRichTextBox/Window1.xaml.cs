using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;


namespace WPFRichTextBox
{
	/// <summary>
	/// Interaction logic for Window1.xaml
	/// </summary>

	public partial class Window1 : System.Windows.Window
	{

		public Window1()
		{
			InitializeComponent();
		}

		protected void BlockTheCommand(object sender, CanExecuteRoutedEventArgs e)
		{
			e.CanExecute = false;
			e.Handled = true;
		}
		protected void InsertCurrentDate(object sender, EventArgs e)
		{
			TextRange tr = new TextRange(XAMLRichBox.Selection.Start, XAMLRichBox.Selection.End);
			tr.Text = DateTime.Now.ToShortDateString();
		}
	}
}