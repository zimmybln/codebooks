using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml;
using System.IO;

namespace WPFRichTextBox
{
	public class CompositeRichTextBox : StackPanel
	{
		protected RichTextBox myRichTextBox;

		public void SetWidth(double width)
		{
			if (width > 10)
			{
				myRichTextBox.MinWidth = width;
				myRichTextBox.MaxWidth = width;
				myRichTextBox.Width = width;
			}
		}
		ToggleButton bold, italic, underline;
		public CompositeRichTextBox()
		{
			this.Orientation = Orientation.Vertical;
			//ShowLabel = false;
			ToolBar toolbar = new ToolBar();

			bold = new ToggleButton();
			TextBlock boldText = new TextBlock(); boldText.Text = "B";
			bold.Content = boldText;
			bold.MinWidth = 30;
			bold.FontWeight = FontWeights.Bold;
			toolbar.Items.Add(bold);

			italic = new ToggleButton();
			TextBlock italicText = new TextBlock(); italicText.Text = "I";
			italic.Content = italicText;
			italic.MinWidth = 30;
			italicText.FontStyle = FontStyles.Italic;
			toolbar.Items.Add(italic);

			underline = new ToggleButton();
			TextBlock underlineText = new TextBlock(); underlineText.Text = "U";
			underline.Content = underlineText;
			underline.MinWidth = 30;
			underlineText.TextDecorations.Add(TextDecorations.Underline);
			toolbar.Items.Add(underline);

			this.Children.Add(toolbar);

			myRichTextBox = new RichTextBox();
			myRichTextBox.Height = 200;
			myRichTextBox.AcceptsTab = true;
			myRichTextBox.SpellCheck.IsEnabled = true;
			this.Children.Add(myRichTextBox);

			this.Loaded += new RoutedEventHandler(CompositeRichTextBox_Loaded);
		}

		void CompositeRichTextBox_Loaded(object sender, RoutedEventArgs e)
		{
			bold.CommandTarget = myRichTextBox;
			bold.Command = EditingCommands.ToggleBold;

			italic.CommandTarget = myRichTextBox;
			italic.Command = EditingCommands.ToggleItalic;

			underline.CommandTarget = myRichTextBox;
			underline.Command = EditingCommands.ToggleUnderline;
		}

		public string GetTextValue()
		{
			TextRange tr = new TextRange(myRichTextBox.Document.ContentStart, myRichTextBox.Document.ContentEnd);
			MemoryStream ms = new MemoryStream();
			tr.Save(ms, DataFormats.Xaml);
			string xamlString = ASCIIEncoding.Default.GetString(ms.ToArray());
			return xamlString;
		}
	}
}
